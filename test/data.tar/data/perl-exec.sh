./dwarfs perl.dwarfs /tmp/perl/install -o cachesize=1g -o workers=4 -f &
sleep 1

wait
